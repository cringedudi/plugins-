Запуск: в папке todo_db выполнить   php -S localhost:8000
Открыть: http://localhost:8000
(нужен PHP с расширением pdo_sqlite; файл tasks.db создастся сам)
