<?php
header("Content-Type: application/json");

$db = new PDO("sqlite:tasks.db");
$db->exec("CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  priority TEXT NOT NULL CHECK (priority IN ('low','medium','high')),
  done INTEGER NOT NULL DEFAULT 0
)");

$method = $_SERVER["REQUEST_METHOD"];
$data = json_decode(file_get_contents("php://input"), true);
$id = $_GET["id"] ?? null;

if ($method == "POST") {
  $db->prepare("INSERT INTO tasks (title, priority) VALUES (?, ?)")
     ->execute([$data["title"], $data["priority"]]);
}
if ($method == "PUT") {
  $db->prepare("UPDATE tasks SET done = ? WHERE id = ?")
     ->execute([$data["done"], $id]);
}
if ($method == "DELETE") {
  if ($id) $db->prepare("DELETE FROM tasks WHERE id = ?")->execute([$id]);
  else $db->exec("DELETE FROM tasks WHERE done = 1");
}

echo json_encode($db->query("SELECT * FROM tasks ORDER BY id")->fetchAll(PDO::FETCH_ASSOC));
