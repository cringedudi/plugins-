const form = document.querySelector("#form");
const input = document.querySelector("#text");
const select = document.querySelector("#priority");
const error = document.querySelector("#error");
const list = document.querySelector("#list");
const count = document.querySelector("#count");
const names = { low: "Низкий", medium: "Средний", high: "Высокий" };

// запрос к серверу; сервер возвращает актуальный список задач
async function send(method, url = "api.php", body) {
  const r = await fetch(url, { method, body: body && JSON.stringify(body) });
  render(await r.json());
}

function render(tasks) {
  list.innerHTML = "";
  for (const t of tasks) {
    const li = document.createElement("li");
    li.className = t.priority;
    li.dataset.id = t.id;
    if (Number(t.done)) li.classList.add("done");

    const span = document.createElement("span");
    span.className = "text";
    span.textContent = t.title;

    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = names[t.priority];

    const del = document.createElement("button");
    del.textContent = "×";

    li.append(span, badge, del);
    list.append(li);
  }
  count.textContent = list.querySelectorAll("li:not(.done)").length;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const title = input.value.trim();
  if (!title) {
    error.hidden = false;
    return;
  }
  error.hidden = true;
  send("POST", "api.php", { title, priority: select.value });
  input.value = "";
});

list.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (e.target.classList.contains("text")) {
    const done = li.classList.contains("done") ? 0 : 1;
    send("PUT", "api.php?id=" + li.dataset.id, { done });
  }
  if (e.target.tagName === "BUTTON") send("DELETE", "api.php?id=" + li.dataset.id);
});

document.querySelector("#clear").addEventListener("click", () => send("DELETE"));

send("GET");
