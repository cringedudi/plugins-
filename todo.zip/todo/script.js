const form = document.querySelector("#form");
const input = document.querySelector("#text");
const select = document.querySelector("#priority");
const error = document.querySelector("#error");
const list = document.querySelector("#list");
const count = document.querySelector("#count");

function update() {
  count.textContent = list.querySelectorAll("li:not(.done)").length;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) {
    error.hidden = false;
    return;
  }
  error.hidden = true;

  const li = document.createElement("li");
  li.className = select.value;

  const span = document.createElement("span");
  span.className = "text";
  span.textContent = text;

  const badge = document.createElement("span");
  badge.className = "badge";
  badge.textContent = select.options[select.selectedIndex].text;

  const del = document.createElement("button");
  del.textContent = "×";

  li.append(span, badge, del);
  list.append(li);
  input.value = "";
  update();
});

list.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (e.target.classList.contains("text")) li.classList.toggle("done");
  if (e.target.tagName === "BUTTON") li.remove();
  update();
});

document.querySelector("#clear").addEventListener("click", () => {
  list.querySelectorAll("li.done").forEach((li) => li.remove());
  update();
});
